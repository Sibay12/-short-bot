# TAKNA TECHNOLOGY Shorts Bot – Animation Upgrade

1. Copy `story_animation.py` and `apply_animation_upgrade.py` to the root of your existing `short-bot` repository.
2. Copy the supplied `assets` folder into the repository root.
3. Run `python apply_animation_upgrade.py` from the repository root.
4. Review the changed `make_short.py` and `requirements.txt`, then commit and push.
5. Run Actions → Daily Short → Run workflow with `dry_run=1`. Inspect the artifact before uploading.

This patch replaces only the renderer block and adds Pillow. It preserves the existing Hindi voice/TTS, captions, music, SEO metadata, YouTube upload, topic history and daily workflow.

Animation note: this is a free procedural 2D cartoon prototype using Pillow + FFmpeg. It animates a consistent simple host (body bob and arm gestures), scene backgrounds, particles and the logo. Scene environments are selected by broad story keywords. It is not a fully AI-generated cartoon film with complex acting, accurate lip-sync or unique detailed character art for every story beat. Review the output before public upload.

The current workflow already runs once daily at 5:00 PM IST. Keep it as a temporary starting time because the channel has no useful audience analytics yet. A second video can be created manually. Keep `dry_run=1` for previews; use `0` only when ready to upload.
